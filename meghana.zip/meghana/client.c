#include<stdio.h>
#include"header.h"
int push(int* s,int* t,int size,int x)
  {
    //check for overflow
    if(*t==size-1)
     {
       printf("\nStack overflow\n");
       return -1;
     }

    ++*t;
   s[*t]=x;
   return(1);
  }


  int pop(int *s,int *t)
  {
   int x;
   //check for underflow
   if(*t==-1)
   {
     printf("stack Underflow..\n");
     return(-1);
   }
   x=s[*t];
   --*t;
   return x;
  }

  void display(int *s, int t)
  {
    int i;
    if(t==-1)
      printf("\nEmpty stack\n");
   else
   {
    for(i=t;i>=0;--i)
       printf("%d  ",s[i]);
    printf("\n");
  }
 }

