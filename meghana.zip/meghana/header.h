int push(int*,int*,int,int);
int pop(int*,int*);
void display(int*,int);
